
let map;
let eventsData = [];

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 0, lng: 0 },
        zoom: 12,
    });

    getCurrentLocation();
}

function getCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };

                map.setCenter(userLocation);
                searchNearbyEvents(userLocation);
            },
            (error) => {
                console.error(`Error getting location: ${error.message}`);
            }
        );
    } else {
        console.error("Geolocation is not supported by this browser.");
    }
}

function searchNearbyEvents(location) {
    const placesService = new google.maps.places.PlacesService(map);
    const request = {
        location: location,
        radius: 20000, // 20 km in meters
        type: 'point_of_interest', // Adjust based on event types
    };

    placesService.nearbySearch(request, (results, status) => {
        if (status === google.maps.places.PlacesServiceStatus.OK) {
            eventsData = results.map(event => {
                return {
                    name: event.name,
                    address: event.vicinity,
                    location: {
                        lat: event.geometry.location.lat(),
                        lng: event.geometry.location.lng()
                    }
                };
            });

            saveDataToLocalStorage();
            console.log(eventsData);
        } else {
            console.error(`Error fetching nearby places: ${status}`);
        }
    });
}

function saveDataToLocalStorage() {
    localStorage.setItem('eventsData', JSON.stringify(eventsData));
}
