import React from "react";
import Laptop from "../assets/causeConnect.png";

const Analytics = () => {
  return (
    <div className="w-full bg-white py-16 px-4">
      <div className="max-w-[1240px] mx-auto grid md:grid-cols-2">
        <img className="w-[500px] mx-auto my-4" src={Laptop} alt="/" />
        <div className="flex flex-col justify-center">
          <p className="text-blue-400 font-bold ">Here's How to Use</p>
          <h1 className="md:text-4xl sm:text-5xl text-2xl font-bold py-3">
            Cause Connect
          </h1>
          <div className="columns-2">
            <div>
              <h1 className="md:text-3xl sm:text-2xl text-2xl font-bold py-2">
                For NGOs
              </h1>
              <p>1. Signup as a Non-Profit Organization</p>
              <p>2. List Your Events or Drives</p>
              <p>3. Collaborate with Individuals who apply to volunteer</p>
              <button className="bg-black text-blue-300 w-[200px] rounded-md font-medium my-6 mx-auto md:mx-0 py-3">
                Register as NGO
              </button>
            </div>
            <div>
              <h1 className="md:text-3xl sm:text-2xl text-2xl font-bold py-2">
                For Individuals
              </h1>
              <p>1. Sign Up as an Individual Volunteer</p>
              <p>2. Find Top NGOs or Events Near You</p>
              <p>3. Apply to help and be part of a greater cause</p>
              <button className="bg-black text-blue-300 w-[200px] rounded-md font-medium my-6 mx-auto md:mx-0 py-3">
                Register as Volunteer
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
