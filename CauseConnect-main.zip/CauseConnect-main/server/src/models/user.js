const { timeStamp } = require("console");
const mongoose = require("mongoose");
const Userschema = mongoose.Schema({
    usernmae:{
        type : String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true
    }
},{timestamps:true});
module.exports = mongoose.model("User", Userschema);