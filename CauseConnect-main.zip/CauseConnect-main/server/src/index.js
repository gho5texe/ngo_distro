const express =require("express");
const app = express();
const userRouter = require("./routes/userRoutes");
const noteRouter = require("./routes/noteRoutes");
 
const mongoose = require("mongoose")
app.use(express.json());

app.use("/users", userRouter);
app.use("/note", noteRouter);
app.get("/", (req,res)=>{
    res.send("Hello");
});
mongoose.connect("mongodb+srv://hritiksingh23k:Greenapple8*@cluster0.ytvahez.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
.then(()=>{
    app.listen(5000, ()=>{
        console.log("Server Started on port no. 5000");
    });
})
.catch((error)=>{
     console.log(error);   
})
